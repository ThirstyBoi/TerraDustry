require("terror");
//effectlib, funclib and scourge script owned by EoD
require("effectlib");
require("funclib");
require("eof");
require("rainbow");